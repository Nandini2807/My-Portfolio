'use strict';

const header = document.querySelector("[data-header]");
const navToggleBtn = document.querySelector("[data-nav-toggle-btn]");

navToggleBtn.addEventListener("click", function () {
  header.classList.toggle("nav-active");
  this.classList.toggle("active");
});


const navbarLinks = document.querySelectorAll("[data-nav-link]");

for (let i = 0; i < navbarLinks.length; i++) {
  navbarLinks[i].addEventListener("click", function () {
    header.classList.toggle("nav-active");
    navToggleBtn.classList.toggle("active");
  });
}

const backTopBtn = document.querySelector("[data-back-to-top]");

window.addEventListener("scroll", function () {
  if (window.scrollY >= 100) {
    header.classList.add("active");
    backTopBtn.classList.add("active");
  } else {
    header.classList.remove("active");
    backTopBtn.classList.remove("active");
  }
});

document.addEventListener("DOMContentLoaded", function() {
  const cursor = document.createElement('div');
  cursor.classList.add('cursor');
  document.body.appendChild(cursor);

  document.addEventListener('mousemove', function(e) {
      cursor.style.left = `${e.clientX}px`;
      cursor.style.top = `${e.clientY}px`;
  });

  document.addEventListener('mousedown', function() {
      cursor.classList.add('clicked');
  });

  document.addEventListener('mouseup', function() {
      cursor.classList.remove('clicked');
  });

  document.querySelectorAll('a, button, .interactive-element').forEach(item => {
      item.addEventListener('mouseenter', () => {
          cursor.classList.add('hovered');
          // Change cursor shape or size based on element type
          if (item.tagName === 'A') {
            cursor.style.transform = 'scale(1.2)';
            cursor.style.borderRadius = '50%';
          } else if (item.tagName === 'BUTTON') {
            cursor.style.transform = 'scale(1.5)';
            cursor.style.borderRadius = '10px';
          } else {
            cursor.style.transform = 'scale(1)';
            cursor.style.borderRadius = '0';
          }
      });
      item.addEventListener('mouseleave', () => {
          cursor.classList.remove('hovered');
          cursor.style.transform = 'scale(1)';
          cursor.style.borderRadius = '0';
      });
  });
});

var tl= gsap.timeline()

tl.from(" h1  ",{
    y:-30,
    opacity:0,
    duration:0.5,
    delay:1,
    stagger:0.3,

})


var tl= gsap.timeline()

tl.from(" li ",{
    y:-30,
    opacity:0,
    duration:0.5,
    delay:1.5,        
    stagger:0.3,
})
window.addEventListener('load', function() {
  setTimeout(function() {
    window.scrollTo(0, 0);
  }, 100);
});